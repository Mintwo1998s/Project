/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AssUI.DAO;

import AssUI.DatabaseHelper;
import AssUI.model.GRADE;
import AssUI.model.STUDENTS;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.sql.rowset.serial.SerialBlob;

/**
 *
 * @author Dell
 */
public class GRADEDao {
        public boolean insert(GRADE bd) throws Exception   {
       String sql ="INSERT INTO DBO.GRADE(MASV,TIENGANH,TINHOC,GDTC) " +
               "VALUES (?,?,?,?)";
        System.out.println(sql);
        try {
            Connection con = DatabaseHelper.openConnection();
                PreparedStatement pstmt = con.prepareStatement(sql);
                pstmt.setString(1,bd.getMASV());
                pstmt.setString(2,bd.getHoTen());
                pstmt.setFloat(2,bd.getTiengAnh());
                pstmt.setFloat(3,bd.getTinHoc()); 
                pstmt.setFloat(4,bd.getGDTC());
                 pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
               }     
            return false;
        }
 public boolean update(GRADE bd) throws Exception {
        String sql = "UPDATE DBO.GRADE "
                + "SET TIENGANH= ?,TINHOC = ?,GDTC = ?"
                + " where MASV =?";
        System.out.println(sql);
        try {
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1,bd.getHoTen());
            pstmt.setFloat(1, bd.getTinHoc());
            pstmt.setFloat(2, bd.getTiengAnh());
            pstmt.setFloat(3, bd.getGDTC());
            pstmt.setString(4, bd.getMASV());;
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
            return false;
    }
  public boolean delete(String MASV) throws Exception {
        String sql = "delete from GRADE " + "where MASV =?";
        System.out.println(sql);
        try {
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, MASV);
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
            return false;
    }

    public GRADE findById(String MASV) throws Exception {
        String sql = " select sv.MASV,sv.HOTEN,bd.TIENGANH,bd.TINHOC,bd.GDTC,bd.MASV FROM GRADE bd ,STUDENTS sv "
                + "where bd.MASV = sv.MASV and sv.masv =?";
        System.out.println(sql);
        GRADE bd = null;

         try {
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, MASV);
            ResultSet rs = pstmt.executeQuery();    
            while (rs.next()) {
                bd = createGRADE(rs);
                return bd;
            }
                
        } catch(Exception e)    {
            e.printStackTrace();
        }
        return bd;
    }

    private GRADE createGRADE(final ResultSet rs) throws SQLException {
        GRADE bd = new GRADE();
        bd.setMASV(rs.getString("MASV"));
        bd.setHoTen(rs.getString("HOTEN"));
        bd.setTiengAnh(rs.getFloat("TIENGANH"));
        bd.setTinHoc(rs.getFloat("TINHOC"));
        bd.setGDTC(rs.getFloat("GDTC"));
        return bd;
    }

    public List<GRADE> findAll() throws Exception {
        List< GRADE> list = new ArrayList<>();
        String sql = " select sv.MASV,sv.HOTEN,bd.TIENGANH,bd.TINHOC,bd.GDTC FROM GRADE bd ,STUDENTS sv "
                + "where bd.MASV = sv.MASV ";
        System.out.println(sql);
        try {
            Connection con = DatabaseHelper.openConnection();
            Statement pstmt = con.createStatement();
           ResultSet rs = pstmt.executeQuery(sql); 
                
                while (rs.next()) {
                    GRADE bd = createGRADE(rs);
                    list.add(bd);
                }
                
        } catch(Exception e)    {
            e.printStackTrace();
        }
    return list;
    }
    public List<GRADE> findtop3() throws Exception {
        List< GRADE> list = new ArrayList<>();
        String sql = " select top 3 sv.MASV,sv.HOTEN,bd.TIENGANH,bd.TINHOC,bd.GDTC FROM GRADE bd ,STUDENTS sv \n" +
                        "where bd.MASV = sv.MASV order by (tienganh+tinhoc+gdtc) /3 desc ";
        System.out.println(sql);
        try {
            Connection con = DatabaseHelper.openConnection();
            Statement pstmt = con.createStatement();
           ResultSet rs = pstmt.executeQuery(sql); 
                
                while (rs.next()) {
                    GRADE bd = createGRADE(rs);
                    list.add(bd);
                }
                
        } catch(Exception e)    {
            e.printStackTrace();
        }
    return list;
    }
}
 
