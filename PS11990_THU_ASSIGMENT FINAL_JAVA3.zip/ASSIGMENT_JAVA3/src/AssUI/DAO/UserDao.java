/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AssUI.DAO;

import AssUI.DatabaseHelper;
import AssUI.modal.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
/**
 *
 * @author Dell
 */
public class UserDao {
    public boolean checkLogin(User user) throws Exception   {
       String sql ="select * from Users" 
               + " where  Username=? and Passwordd=?";
        System.out.println(sql);
       boolean check = false;
        try {
            Connection con = DatabaseHelper.openConnection();
                PreparedStatement pstmt = con.prepareStatement(sql);
                pstmt.setString(1,user.getUsername());
                pstmt.setString(2,user.getPassword());
                ResultSet rs = pstmt.executeQuery();
                while(rs.next()){
                    check = true;
                }
                con.close();
                JOptionPane.showMessageDialog(null, check);

        } catch (Exception e) {
        }
                     return check;

    }
    
    public boolean login(User user) throws Exception{
        boolean success = false;
        Statement statement = null;
        try {
            String sql = "select * from users where username ='" + user.getUsername() + "' and passwordd = '" + user.getPassword() + "'";
            System.out.println(sql);
            Connection con = DatabaseHelper.openConnection();
            statement = con.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            while(resultSet.next()){
                    success = true;
                }
                con.close();
                JOptionPane.showMessageDialog(null, success); 

        } catch (Exception ex) {
            System.out.println("Lỗi trong quá trình đăng ký " + ex);
            ex.printStackTrace();
           // throw ex;
        }
        return success;
    }
    
}


