/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AssUI.DAO;

import AssUI.DatabaseHelper;
import AssUI.model.GRADE;
import AssUI.model.STUDENTS;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Dell
 */
public class STUDENTSDao {

    public void insert(STUDENTS sv) throws Exception {
        String sql = "INSERT INTO students VALUES (?,?,?,?,?,?,?)";
        System.out.println(sql);
        // boolean check = false;
        try {
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, sv.getMASV());
            pstmt.setString(2, sv.getHOTEN());
            pstmt.setString(3, sv.getEMAIL());
            pstmt.setString(4, sv.getSODT());
            pstmt.setBoolean(5, sv.isGIOITINH());
            pstmt.setString(6, sv.getDIACHI());
            pstmt.setString(7, sv.getHINH());

            pstmt.executeUpdate();

//               File input = null;
//                BufferedImage read = ImageIO.read(input);
//                Blob HINH = null;
//                if(sv.getHINH() != null){
//                    HINH = new SerialBlob(sv.getHINH());
//                }else{
//                    HINH = null;
//                 //  pstmt.setBlob(7,HINH);
//                }
//                pstmt.setBlob(7,HINH);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update(STUDENTS sv) throws Exception {
        String sql = "UPDATE DBO.Students "
                + "SET HOTEN = ?,EMAIL = ?,SODT = ?,GIOITINH = ? ,DIACHI = ?,HINH = ?"
                + " where MASV = ? ";
        System.out.println(sql);
        try {
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, sv.getHOTEN());
            pstmt.setString(2, sv.getEMAIL());
            pstmt.setString(3, sv.getSODT());
            pstmt.setBoolean(4, sv.isGIOITINH());
            pstmt.setString(5, sv.getDIACHI());
            pstmt.setString(6, sv.getHINH());
            pstmt.setString(7, sv.getMASV());
            pstmt.executeUpdate();
//                if(sv.getHINH() != null){
//                   Blob HINH = new SerialBlob(sv.getHINH());
//                   pstmt.setBlob(6,HINH);
//                }else{
//                   Blob HINH = null;
//                   pstmt.setBlob(6,HINH);
//                }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(String MASV) throws Exception { 
        String sql = "delete from STUDENTS " + "where MASV = ?";
        System.out.println(sql);
        try {
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);

            pstmt.setString(1, MASV);

            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public STUDENTS findById(String MASV) throws Exception {
        String sql = "select * from students  WHERE MASV =?";
        STUDENTS sv = null;
        try {
            Connection con = DatabaseHelper.openConnection();
                PreparedStatement pstmt = con.prepareStatement(sql); 
            pstmt.setString(1, MASV);
            ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                     sv = createSTUDENTS(rs);
                }
                

            } catch(Exception e)    {
                e.printStackTrace();
        }
            return sv;
    }

    private STUDENTS createSTUDENTS(final ResultSet rs) throws SQLException {
        STUDENTS sv = new STUDENTS();
        sv.setMASV(rs.getString("MASV"));
        sv.setHOTEN(rs.getString("HOTEN"));
        sv.setEMAIL(rs.getString("EMAIL"));
        sv.setSODT(rs.getString("SODT"));
        sv.setDIACHI(rs.getString("DIACHI"));
        sv.setGIOITINH(rs.getBoolean("GIOITINH"));
        sv.setHINH(rs.getString("HINH"));
        return sv;
    }

    public List<STUDENTS> findAll() throws Exception {
        String sql = " select * from STUDENTS ";
        try (Connection con = DatabaseHelper.openConnection();
                PreparedStatement pstmt = con.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List< STUDENTS> list = new ArrayList<>();
                while (rs.next()) {
                    STUDENTS sv = createSTUDENTS(rs);
                    list.add(sv);
                }
                return list;
            }
        }

    }
}
