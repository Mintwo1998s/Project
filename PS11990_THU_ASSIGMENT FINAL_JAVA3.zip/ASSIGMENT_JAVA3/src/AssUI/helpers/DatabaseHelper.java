/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AssUI;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Dell
 */
public class DatabaseHelper {
    public static Connection openConnection() throws Exception{
     Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
     String connectionUrl ="jdbc:sqlserver://localhost:1433;databaseName=Students_Management";
     String username = "sa";
     String password="123";
     Connection con = DriverManager.getConnection(connectionUrl, username, password);
     return con;
    }
}
