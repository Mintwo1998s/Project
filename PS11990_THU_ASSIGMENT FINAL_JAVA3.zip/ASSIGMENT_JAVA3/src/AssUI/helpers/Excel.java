/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AssUI.helpers;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLOutput;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Dell
 */
public class Excel {
    public static void main(String[] args) {
        String sql = " select * from STUDENTS ";
        try {
            toExcel(sql, "123");
        } catch (Exception ex) {
            Logger.getLogger(Excel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void toExcel(String sql, String nameSheet) throws Exception    {
        XSSFWorkbook excelTableExport = null;
        BufferedOutputStream excelBOU = null;
        FileOutputStream fos = null;
//        Chọn vị trí để lưu
        JFileChooser excelFileChoose = new JFileChooser("user.home");
//        Đổi tiêu đề tên Dialog
        excelFileChoose.setDialogTitle("Save as");
//        Chỉ cho phép lưu dưới dạng:
        FileNameExtensionFilter fnef = new FileNameExtensionFilter("EXCEL FILES", "xls", "xlsx", "xlsm");
        excelFileChoose.setFileFilter(fnef);
        int excelChooser =  excelFileChoose.showSaveDialog(null);
        if (excelChooser == JFileChooser.APPROVE_OPTION)    {

            try {
                excelTableExport = new XSSFWorkbook();
                XSSFSheet ws = excelTableExport.createSheet(nameSheet);
                ResultSet rs;
                System.out.println(sql);
               Connection con = AssUI.DatabaseHelper.openConnection();
                Statement pstmt = con.createStatement(); 
                rs = pstmt.executeQuery(sql);
                ResultSetMetaData rsmt = rs.getMetaData();
                XSSFCell excelCell;
                XSSFRow excelRow;
//           Xuất tên cột ra dữ liệu
//          Dữ liệu cho hàng tiêu đề
                excelRow = ws.createRow(0);
                for (int j = 0; j < rsmt.getColumnCount()-1; j++) {
                    excelCell = excelRow.createCell(j);
                    String values =rsmt.getColumnName(j+1);
                    excelCell.setCellValue(values);
                }
//                Dữ liệu cho các hàng còn lại
                int i = 1;
                while (rs.next())   {
                    excelRow = ws.createRow(i);
                    for (int j = 0; j < rsmt.getColumnCount() - 1; j++) {
                        excelCell = excelRow.createCell(j);
                        String values;
                        if (rsmt.getColumnName(j+1).equals("GIOITINH"))   {
                            values = rs.getString(j+1).equals("1")? "Nam":"Nữ";
                        } else {
                            values = rs.getString(j+1);
                        }
                        excelCell.setCellValue(values);
                    }
                    i++;
                }
                fos = new FileOutputStream(excelFileChoose.getSelectedFile() + ".xlsx");
                excelBOU = new BufferedOutputStream(fos);
                excelTableExport.write(excelBOU);
                JOptionPane.showMessageDialog(null, "Xuất file thành công!");
                System.out.println("Xuất file thành công!");
            }
            catch (SQLException | ClassNotFoundException | IOException e)   {
                System.out.println("Lỗi trong quá trình xuất ra Excel!");
                e.printStackTrace();
            }
            finally {
                try {
                    if (excelBOU != null)   {
                        excelBOU.close();
                    }
                    if (fos != null)    {
                        fos.close();
                    }
                    if (excelTableExport != null) {
                        excelTableExport.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
}
