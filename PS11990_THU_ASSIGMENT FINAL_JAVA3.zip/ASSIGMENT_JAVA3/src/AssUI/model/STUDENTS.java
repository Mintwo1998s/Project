/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AssUI.model;

/**
 *
 * @author Dell
 */
public class STUDENTS {
    private String MASV,HOTEN,SODT,EMAIL,DIACHI;
    private boolean GIOITINH;
    private String HINH;
    public STUDENTS[] get;

    public STUDENTS() {
    }

    public STUDENTS(String MASV, String HOTEN,String EMAIL, String SODT,boolean GIOITINH,String DIACHI ,String HINH) {
        this.MASV = MASV;
        this.HOTEN = HOTEN;
        this.EMAIL = EMAIL;
        this.SODT = SODT;
        this.GIOITINH = GIOITINH;
        this.DIACHI = DIACHI;
        this.HINH = HINH;
    }

    public STUDENTS(String giang, String phan, String gpcodergmailcom) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getMASV() {
        return MASV;
    }

    public void setMASV(String MASV) {
        this.MASV = MASV;
    }

    public String getHOTEN() {
        return HOTEN;
    }

    public void setHOTEN(String HOTEN) {
        this.HOTEN = HOTEN;
    }

    public String getSODT() {
        return SODT;
    }

    public void setSODT(String SODT) {
        this.SODT = SODT;
    }

    public String getEMAIL() {
        return EMAIL;
    }

    public void setEMAIL(String EMAIL) {
        this.EMAIL = EMAIL;
    }

    public String getDIACHI() {
        return DIACHI;
    }

    public void setDIACHI(String DIACHI) {
        this.DIACHI = DIACHI;
    }

    public boolean isGIOITINH() {
        return GIOITINH;
    }

    public void setGIOITINH(boolean GIOITINH) {
        this.GIOITINH = GIOITINH;
    }

    public String getHINH() {
        return HINH;
    }

    public void setHINH(String HINH) {
        this.HINH = HINH;
    }

  
    }



   

